window.SeriesDB = {};

SeriesDB.Views = {};
SeriesDB.Collections = {};
SeriesDB.Models = {};
SeriesDB.Routers = {};

window.app = {};
app.routers = {};
app.plugs = {};
app.views = {};
app.collections = {};