SeriesDB.Collections.SeriesCollection = Backbone.Collection.extend({
    model: SeriesDB.Models.SerieModel,
    url:"/api/series",
    name: "series",
});