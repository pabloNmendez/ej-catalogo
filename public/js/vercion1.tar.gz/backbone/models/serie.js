SeriesDB.Models.SerieModel = Backbone.Model.extend({
	urlRoot:"/api/series"
});