SeriesDB.Views.SerieNewView = Backbone.View.extend({
	events:{
		"click #btn-save" : "create",
	},
	className:"",
	initialize : function($el){
		this.$el = $el;
		// this.template = _.template($("#ArticleNew_tpl").html());
	},
	create : function(){
		console.log('Button fue clickeado');
		if (this.$el.find('#txt-title').val())
		var title = this.$el.find('#txt-title').val();
		var year = this.$el.find('#txt-year').val();
		var poster = this.$el.find('#txt-poster').val();
		var seasons = this.$el.find('#txt-seasons').val();
		var genre = this.$el.find('#slc-genre').val();
		var summary = this.$el.find('#txt-summary').val();

		var model = new SeriesDB.Models.SerieModel({
			title : title,
        	year : year,
        	poster : poster,
        	seasons : seasons,
        	genre : genre,
        	summary : summary
		});

		var xhr = model.save();

		xhr.done(function(data){
			window.app.collections.series.add(data);
			Backbone.history.navigate('serie/'+data._id, {trigger: true});
		});
	},
	render: function(data) {
		// var self = this;
		// var locals ={};

		// this.$el.html(this.template({data:locals}));

		// return this;
	}
});
