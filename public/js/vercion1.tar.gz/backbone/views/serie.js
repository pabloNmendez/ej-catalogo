SeriesDB.Views.SerieView = Backbone.View.extend({

	events:{
		"click > article.item" : "navigate",
		"click #btn-edit" 	: "editar",
		"click #btn-save" 	: "guardar",
		"click #btn-delete" : "borrar",
	},
	className:"",
	initialize : function(){
		var self = this;

		this.model.on('change', function(){
			self.render();
		});

		window.app.routers.on('route:root', function(){
			self.render();
		});

		window.app.routers.on('route:serieSingle', function(){
			self.render();
		});

		this.template = swig.compile($("#Serie_tpl").html());
		this.templateExtended = swig.compile($("#SerieExtended_tpl").html());
	},
	navigate : function(){
		console.log('navigate',this.model.toJSON() );

		Backbone.history.navigate('serie/' + this.model.get('_id'), {trigger: true});
	},

	editar : function(){
		var self = this;
		console.log("edit model ->", this.model);

		$('#txt-title').val(this.model.get('title'));
		$('#txt-year').val(this.model.get('year'));
		$('#txt-poster').val(this.model.get('poster'));
		$('#txt-seasons').val(this.model.get('seasons'));
		$('#slc-genre').val(this.model.get('genre'));
		$('#txt-summary').val(this.model.get('summary'));

	},

	guardar : function(e){

	 	this.model.set({
 			title 	: $('#txt-title').val(),
			year 	: $('#txt-year').val(),
			poster 	: $('#txt-poster').val(),
			seasons : $('#txt-seasons').val(),
			genre 	: $('#slc-genre').val(),
			summary : $('#txt-summary').val(),
        });


        this.model.save();

	},

	borrar : function(e){

 		this.model.destroy({
            success: function () {
                alert('Wine deleted successfully');
                window.navigate("/");
            }
    	});
    	return false;

	},



	render: function() {
		var self = this;
		var locals ={
			post : this.model.toJSON()
		};
		console.log('render',locals);
		if(window.app.state === "serieSingle"){
			if(window.app.serie === this.model.get('_id') ){
				this.$el.show();
				this.$el.html( this.templateExtended(locals) );
			}else{
				this.$el.hide();
				this.$el.html('');
			}
		}else{
			this.$el.html( this.template(locals) );
		}

		return this;
	}
});
