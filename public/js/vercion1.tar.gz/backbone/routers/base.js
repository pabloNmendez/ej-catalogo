SeriesDB.Routers.BaseRouter = Backbone.Router.extend({
	routes: {
		"" :  "root",
		"serie/:id" : "serieSingle"
	},
	initialize : function(){
		var self = this;

	},
	root: function(){
		var self = this;

		console.log('root');

		window.app.state = "root";
	},
	serieSingle : function(id){
		console.log('serieSingle', id);

		window.app.state = "serieSingle";
		window.app.serie = id;
	}
});