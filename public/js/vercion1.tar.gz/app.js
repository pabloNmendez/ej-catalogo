Backbone.View.prototype.close = function () {
    console.log('Closing view ' + this);
    if (this.beforeClose) {
        this.beforeClose();
    }
    this.remove();
    this.unbind();
};

$(function(){


    console.log('Starting app');

    app.collections.series = new SeriesDB.Collections.SeriesCollection();

    //app.views.serieNew = new SeriesDB.Views.SerieNewView( $('#contenido > aside') );


    app.collections.series.on('add', function(item){
        var view = new SeriesDB.Views.SerieView({model:item});
        view.render();
        view.$el.appendTo("#contenido");
    });

    app.collections.series.fetch(
        {success: function(){
   //         app.views.series = new SeriesDB.Views.SeriesListView({model: app.collections.series});

        }});

    app.routers = new SeriesDB.Routers.BaseRouter();
/*
    var xhr = $.get('/api/series');

        xhr.done(function(data){
            console.log(data);
            data.forEach(function(item){
            app.collections.series.add(item);
        });

        Backbone.history.start({
            root : "/",
            pushState : true,
            silent : false
        });
    });
*/
    Backbone.history.start({
            root : "/",
            pushState : true,
            silent : false
    });
    $('nav li:first').on('click', function(){
        Backbone.history.navigate('', {trigger: true});
    });

});


/*



$.get("/api/tvshows",function(rs){console.log(rs)});

serie = {
        title : "The Big Bang Theory",
        year : 2007,
        poster : 'http://ia.media-imdb.com/images/M/MV5BMjI1Mzc4MDUwNl5BMl5BanBnXkFtZTgwMDAzOTIxMjE@._V1_SY317_CR20,0,214,317_AL_.jpg',
        seasons : 10,
        genre : 'Comedy',
        summary : 'The Big Bang Theory es una comedia de situación estadounidense estrenada el 24 de septiembre de 2007 por la cadena CBS.Está producida por la Warner Bros y Chuck Lorre.1 Fue ese mismo año cuando la comedia ganó un Teen Choice Awards en la categoría "Mejor serie de comedia" y Jim Parsons un premio por sus logros individuales en la serie.'
    };

$.post("/api/tvshows",serie,function(rs){console.log(rs)});

*/